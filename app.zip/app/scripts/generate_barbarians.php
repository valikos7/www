<?php
// scripts/generate_barbarians.php
// Запустить 1 раз для заполнения карты варварами

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../core/Database.php';

$database = Database::getInstance();
$db = $database->getPdo();

$count = 200; // Сколько варварских деревень создать
$created = 0;

$names = [
    'Заброшенный хутор', 'Дикий лагерь', 'Разбойничий стан',
    'Варварский посёлок', 'Лесной лагерь', 'Степной аул',
    'Горный форт', 'Прибрежная стоянка', 'Древние руины',
    'Тёмное убежище', 'Форпост разбойников', 'Старое городище',
    'Волчье логово', 'Медвежья берлога', 'Орлиное гнездо',
    'Змеиный оплот', 'Каменный лагерь', 'Речной пост',
    'Туманная застава', 'Ледяной привал'
];

echo "Генерация варварских деревень...\n";

for ($i = 0; $i < $count; $i++) {
    $x = rand(-100, 100);
    $y = rand(-100, 100);

    // Проверяем что координаты свободны
    $stmt = $db->prepare("SELECT id FROM villages WHERE x = ? AND y = ?");
    $stmt->execute([$x, $y]);
    if ($stmt->fetch()) continue;

    $name = $names[array_rand($names)];
    $continent = floor(($y + 500) / 100) * 10 + floor(($x + 500) / 100);

    // Случайные ресурсы
    $wood  = rand(500, 5000);
    $stone = rand(500, 5000);
    $iron  = rand(500, 5000);
    $points = rand(20, 300);

    // Случайные уровни зданий (слабые)
    $main  = rand(1, 5);
    $wall  = rand(0, 3);
    $farm  = rand(1, 3);
    $storage = rand(1, 3);
    $w_lvl = rand(1, 5);
    $s_lvl = rand(1, 5);
    $i_lvl = rand(1, 5);

    $stmt = $db->prepare("INSERT INTO villages 
        (userid, name, x, y, continent, 
         main, wood_level, stone_level, iron_level, farm, storage, wall,
         r_wood, r_stone, r_iron, last_prod_aktu, points)
        VALUES (-1, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?)");

    $stmt->execute([
        $name, $x, $y, $continent,
        $main, $w_lvl, $s_lvl, $i_lvl, $farm, $storage, $wall,
        $wood, $stone, $iron, time(), $points
    ]);

    $created++;
}

echo "Создано варварских деревень: $created из $count запрошенных.\n";
echo "Готово!\n";