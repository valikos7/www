<?php
// scripts/check_system.php
// Запустить один раз для проверки системы

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../core/Database.php';

$database = Database::getInstance();
$db = $database->getPdo();

echo "=== ПРОВЕРКА СИСТЕМЫ " . APP_NAME . " ===\n\n";

// Проверяем таблицы
$required_tables = [
    'users', 'villages', 'unit_place', 'troop_movements',
    'reports', 'messages', 'alliances', 'alliance_members',
    'game_config', 'smith_research', 'settlers',
    'activity_log', 'announcement'
];

echo "📋 ТАБЛИЦЫ БАЗЫ ДАННЫХ:\n";
foreach ($required_tables as $table) {
    try {
        $stmt = $db->query("SELECT COUNT(*) as cnt FROM `$table`");
        $cnt = $stmt->fetch()['cnt'];
        echo "✅ $table ($cnt записей)\n";
    } catch (Exception $e) {
        echo "❌ $table — НЕ НАЙДЕНА!\n";
    }
}

// Проверяем файлы
echo "\n📁 ФАЙЛЫ СИСТЕМЫ:\n";

$required_files = [
    'config/config.php',
    'core/Database.php',
    'core/ResourceManager.php',
    'core/BattleEngine.php',
    'core/NotificationManager.php',
    'core/GameHelper.php',
    'controllers/AuthController.php',
    'controllers/MainController.php',
    'controllers/VillageController.php',
    'controllers/VillagesController.php',
    'controllers/MapController.php',
    'controllers/ProfileController.php',
    'controllers/ReportController.php',
    'controllers/BattleController.php',
    'controllers/AllianceController.php',
    'controllers/MessageController.php',
    'controllers/RankingController.php',
    'controllers/PlayerController.php',
    'controllers/SettlerController.php',
    'controllers/AdminController.php',
    'templates/index.php',
    'templates/login.php',
    'templates/register.php',
    'templates/village.php',
    'templates/villages.php',
    'templates/map.php',
    'templates/profile.php',
    'templates/reports.php',
    'templates/messages.php',
    'templates/message_view.php',
    'templates/message_compose.php',
    'templates/navbar.php',
    'templates/attack_form.php',
    'templates/alliances.php',
    'templates/alliance_view.php',
    'templates/alliance_create.php',
    'templates/ranking.php',
    'templates/player_profile.php',
    'templates/settlers.php',
    'templates/building_main.php',
    'templates/building_barracks.php',
    'templates/building_stable.php',
    'templates/building_smith.php',
    'templates/building_wall.php',
    'templates/building_storage.php',
    'templates/building_hide.php',
    'templates/building_farm.php',
    'templates/building_resource.php',
    'templates/building_garage.php',
    'templates/admin/index.php',
    'templates/admin/players.php',
    'templates/admin/announcements.php',
    'templates/admin/settings.php',
];

$missing = 0;
foreach ($required_files as $file) {
    $path = __DIR__ . '/../' . $file;
    if (file_exists($path)) {
        echo "✅ $file\n";
    } else {
        echo "❌ $file — ОТСУТСТВУЕТ!\n";
        $missing++;
    }
}

// Проверяем настройки
echo "\n⚙ НАСТРОЙКИ ИГРЫ:\n";
$stmt = $db->query("SELECT * FROM game_config");
$settings = $stmt->fetchAll();
foreach ($settings as $s) {
    echo "  {$s['key']} = {$s['value']}\n";
}

// Статистика
echo "\n📊 СТАТИСТИКА:\n";
$tables_stat = [
    'users'    => 'Игроков',
    'villages' => 'Деревень',
    'alliances'=> 'Альянсов',
    'messages' => 'Сообщений',
    'reports'  => 'Отчётов',
];
foreach ($tables_stat as $table => $label) {
    try {
        $stmt = $db->query("SELECT COUNT(*) as cnt FROM `$table`");
        $cnt  = $stmt->fetch()['cnt'];
        echo "  $label: $cnt\n";
    } catch (Exception $e) {}
}

// Итог
echo "\n";
if ($missing === 0) {
    echo "✅ ВСЕ ФАЙЛЫ НА МЕСТЕ! Система готова к работе.\n";
} else {
    echo "⚠ Отсутствует файлов: $missing\n";
    echo "Создайте недостающие файлы!\n";
}

echo "\n=== ПРОВЕРКА ЗАВЕРШЕНА ===\n";